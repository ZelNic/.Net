﻿namespace Task_1
{
    public class DateByMachine
    {
        public int Id { get; set; }
        public double PositionX { get; set; }
        public double PositionY { get; set; }
    }
}
